package com.example.doctorappointment.Data.model.resquest

data class basicRequest( var message:String)