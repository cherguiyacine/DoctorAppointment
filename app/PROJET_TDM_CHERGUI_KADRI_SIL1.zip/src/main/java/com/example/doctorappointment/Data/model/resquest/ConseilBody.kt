package com.example.doctorappointment.Data.model.resquest

data class ConseilBody(var idPatient :Int, var idDoctor:Int, var conseilDescription :String)