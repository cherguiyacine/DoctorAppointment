package com.example.doctorappointment.Data.model.resquest

data class LoginDoctorRequest(var phoneNumber :String, var password:String)