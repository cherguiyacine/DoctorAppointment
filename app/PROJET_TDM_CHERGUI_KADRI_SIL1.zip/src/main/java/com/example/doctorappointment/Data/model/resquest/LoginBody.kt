package com.example.doctorappointment.Data.model.resquest

data class LoginBody(var phoneNumber :String,var password:String)