package com.example.doctorappointment.Data.model.resquest

import java.util.*

data class ReservationBody(var idPatient :Int, var idDoctor:Int, var dateBooking :Date,var heureBooking:String)