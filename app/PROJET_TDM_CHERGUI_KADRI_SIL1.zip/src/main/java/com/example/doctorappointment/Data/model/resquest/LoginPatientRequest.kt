package com.example.doctorappointment.Data.model.resquest

data class LoginPatientRequest(var phoneNumber :String, var password:String)