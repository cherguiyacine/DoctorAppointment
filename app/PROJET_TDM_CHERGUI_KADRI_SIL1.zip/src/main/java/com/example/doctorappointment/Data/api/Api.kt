package com.example.doctorappointment.Data.api

class Api {

}