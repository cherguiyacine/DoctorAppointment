package com.sil1.autolibdz_onboard_computer.ui.viewmodel

class ExampleViewModel {
}